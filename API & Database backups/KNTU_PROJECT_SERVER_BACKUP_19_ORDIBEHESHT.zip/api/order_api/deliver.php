<?php
require_once('../UserValidator.php');
require_once('../QRCodeCipher.php');
require_once('../PersianDate.php');
require_once('../MCrypt.php');
define('HOSTNAME', 'localhost');
define('USERNAME', 'cpres873_Aban');
define('PASSWORD', 'KimiaAndMohammad');
define('DATABASE', 'cpres873_KNTU_Database');
date_default_timezone_set("Asia/Tehran");

$connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");
if ($connect) {
    $token = null;
    $code = null;
    $sharedKey = null;
    $headers = getallheaders();
    foreach ($headers as $key => $val) {
        if (strcmp($key, "Token") == 0)
            $token = $val;
        else if (strcmp($key, "Code") == 0)
            $code = $val;
        else if (strcmp($key, "Encsharedkey") == 0)
            $sharedKey = $val;
    }

    $UserValidator = new UserValidator($token);
    if ($UserValidator->isValidUser()) {
        $QRCodeCipher = new QRCodeCipher($code);
        $cypher = new MCrypt($sharedKey);
        $userID = $UserValidator->getUserID()();
        $restaurantID = $QRCodeCipher->getRestaurantID();
        $token_table = "Token";
        $return_arr = [];
        $data = json_decode(file_get_contents('php://input'), true);
        $totalPrice = 0;
        $date = (new gregorian2jalali)->gregorian_to_jalali() . " " . date("H:i");
        $date2 = (new gregorian2jalali)->gregorian_to_jalali() . " " . date("H:i:s");
        $toDeliverTime = $date;
        $explodedDate = explode("/", explode(" ", $date2)[0]);
        $explodedTime = explode(":", explode(" ", $date2)[1]);
        $qrCodeIssueTrackingNo = $userID . "_LXN_" . $explodedDate[0] . $explodedDate[1] . $explodedDate[2] . $explodedTime[0] . $explodedTime[1] . $explodedTime[2];
        //calculating totalPrice AND then, insert new lexinOrder record
        $bills = $data['specifiedBills'];
        $processedFoodIDS = [];
        foreach ($bills as $bill) {
            $foodID = $bill['foodID'];
            $deskID = -1;
            $countNumber = $bill['counter'];

            if ($foodID > 0 && $deskID == -1) {
                $priceQuery = "SELECT price FROM Food WHERE id = '$foodID'";
                $priceQueryRes = mysqli_query($connect, $priceQuery);
                $foodPrice = mysqli_fetch_assoc($priceQueryRes)['price'];
                $totalPrice = $totalPrice + $foodPrice * $countNumber;
            }
        }
        $discountID = -1;
        $discountPercentage = -1;
        if ($data["discountID"] != -1) {
            $discountID = $data["discountID"];
            $findDiscountIDQuery = "SELECT percentage FROM Discount WHERE id = '$discountID'";
            $findDiscountIDQueryRes = mysqli_query($connect, $findDiscountIDQuery);
            $discountPercentage = mysqli_fetch_assoc($findDiscountIDQueryRes)['percentage'];
            $totalPrice = (1 - $discountPercentage / 100) * $totalPrice;
        }

        if ($discountID != -1)
            mysqli_query($connect, "INSERT INTO RelNormalUserDiscount(normal_user_id,discount_id) VALUES('$userID','$discountID')");
        $query = "INSERT INTO LexinOrder(restaurant_id,discount_id,pay_mode,total_price,qr_code_issue_tracking_no,type,orderer_normal_user_id,to_deliver_time) VALUES('$restaurantID','$discountID','in_app','$totalPrice','$qrCodeIssueTrackingNo','delivery','$userID','$toDeliverTime')";
        $res = mysqli_query($connect, $query);
        $insertedOrderID = mysqli_insert_id($connect);
        //now it's time to insert food bills
        foreach ($bills as $bill) {
            $foodID = $bill['foodID'];
            $deskID = -1;
            $countNumber = $bill['counter'];

            //no calculating total cost and creating query for each mode
            if ($foodID > 0 && $deskID == -1) {
                $priceQuery = "SELECT price FROM Food WHERE id = '$foodID'";
                $priceQueryRes = mysqli_query($connect, $priceQuery);
                $foodPrice = mysqli_fetch_assoc($priceQueryRes)['price'];
                $specifiedTotalFoodPrice = $foodPrice * $countNumber;
                if ($discountPercentage != -1)
                    $specifiedTotalFoodPrice = (1 - $discountPercentage / 100) * $specifiedTotalFoodPrice;
                $query = "INSERT INTO FoodOrder(food_id,count_number,order_id,price) VALUES('$foodID','$countNumber','$insertedOrderID','$specifiedTotalFoodPrice')";
            }
            if ($query != NULL)
                mysqli_query($connect, $query);
        }
        $updateCashOfProfile = "UPDATE NormalUser SET cash = cash - '$totalPrice' WHERE id = '$userID'";
        mysqli_query($connect, $updateCashOfProfile);

        if ($discountPercentage != -1) {
            $discountUsageQuery = "UPDATE Discount SET used_times = used_times+1 WHERE ID = '$discountID'";
            mysqli_query($connect, $discountUsageQuery);
        }

        $latitude = $data['latitude'];
        $longitude = $data['longitude'];
        $floor = $data['floor'];
        $unit = $cypher->decrypt($data['unit']);
        $blockNo = $cypher->decrypt($data['blockNo']);
        $addressQuery = "INSERT INTO Address(block,floor,unit,latitude,longitude) VALUES('$blockNo','$floor','$unit','$latitude','$longitude')";
        mysqli_query($connect, $addressQuery);
        $addressID = mysqli_insert_id($connect);
        $deliverQuery = "INSERT INTO Deliver(deliverer_id,order_id,destination_address_id,status) VALUES('1','$insertedOrderID','$addressID','JUST ORDERER')";
        mysqli_query($connect, $deliverQuery);
        $response['code'] = 101;
        $response['message'] = $insertedOrderID;
        die(json_encode($response));
    }
}
?>

