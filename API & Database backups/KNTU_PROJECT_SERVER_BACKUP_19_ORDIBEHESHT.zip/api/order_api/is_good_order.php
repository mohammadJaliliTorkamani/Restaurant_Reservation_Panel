<?php
require_once('../UserValidator.php');
require_once('../QRCodeCipher.php');
define('HOSTNAME', 'localhost');
define('USERNAME', 'cpres873_Aban');
define('PASSWORD', 'KimiaAndMohammad');
define('DATABASE', 'cpres873_KNTU_Database');

$connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');
if ($connect) {
    $token = null;
    $code = null;
    $headers = getallheaders();
    foreach ($headers as $key => $val) {
        if (strcmp($key, "Token") == 0)
            $token = $val;
        else if (strcmp($key, "Code") == 0)
            $code = $val;

    }

    $UserValidator = new UserValidator($token);
    if ($UserValidator->isValidUser($code)) {
        $QRCodeCipher = new QRCodeCipher($code);
        $restaurantID = $QRCodeCipher->getRestaurantID();
        $decryptedCode = encrypt_decrypt('decrypt', $code);
        $data = json_decode(file_get_contents('php://input'), true);
        $number = $data['n'];
        $totalSum = 0;
        $totalChairNumber = 0;
        $bills = $data['bills'];
        foreach ($bills as $bill) {
            $foodID = $bill["foodID"];
            if ($foodID != -1) {
                $query = "SELECT Food.price FROM Food WHERE Food.id = '$foodID'";
                $result = mysqli_query($connect, $query);
                $price = mysqli_fetch_assoc($result)["price"];
                $totalSum = $totalSum + $price * $bill["counter"];
            } else {
                $totalChairNumber = $totalChairNumber + 1;
            }
        }

        $minFoodQuery = "SELECT MIN(price) as minimum FROM Food WHERE Food.restaurant_id = '$restaurantID' AND deleted = '0' AND valid_to_cook = '1'";
        $minFoodRes = mysqli_query($connect, $minFoodQuery);
        $mimimumPrice = mysqli_fetch_assoc($minFoodRes)['minimum'];
        $ans = ($totalChairNumber <= 1.5 * $number) && ($number * 0.75 * $mimimumPrice <= $totalSum);
        $response['code'] = 102;
        if ($ans)
            $response['code'] = 101;
        die(json_encode($response));

    }
}
?>