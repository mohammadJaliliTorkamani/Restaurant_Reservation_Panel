<?php
define('HOSTNAME', 'localhost');
define('USERNAME', 'cpres873_Aban');
define('PASSWORD', 'KimiaAndMohammad');
define('DATABASE', 'cpres873_KNTU_Database');
$connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");

if ($connect) {
    $response = [];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $query = "UPDATE NormalUser SET password = '$password' WHERE phone = '$phone'";
    $qRes = mysqli_query($connect, $query);
    $response['code'] = 101;
    die(json_encode($response));
}
?>