<?php
require_once('../UserValidator.php');
require_once('../QRCodeCipher.php');
define('HOSTNAME', 'localhost');
define('USERNAME', 'cpres873_Aban');
define('PASSWORD', 'KimiaAndMohammad');
define('DATABASE', 'cpres873_KNTU_Database');

$connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');

if ($connect) {
    mysqli_set_charset($connect, "utf8");
    $token = null;
    $code = null;
    $headers = getallheaders();
    foreach ($headers as $key => $val) {
        if (strcmp($key, "Token") == 0)
            $token = $val;
        else if (strcmp($key, "Code") == 0)
            $code = $val;
    }

    $UserValidator = new UserValidator($token);
    if ($UserValidator->isValidUser()) {
        $QRCodeCipher = new QRCodeCipher($code);
        $restaurantID = $QRCodeCipher->getRestaurantID();
        $query = "SELECT Address.latitude,Address.longitude FROM Restaurant,Address WHERE Restaurant.id = '$restaurantID' AND Restaurant.address_id = Address.id";
        $res = mysqli_query($connect, $query);
        $fetchResul = mysqli_fetch_assoc($res);
        $response['latitude'] = $fetchResul['latitude'];
        $response['longitude'] = $fetchResul['longitude'];
        die(json_encode($response));
    }
}
?>