<?php
require_once("MCrypt.php");
class QRCodeCipher
{
    private $ENCRYPTION_KEY =  137613770429;

    private $encryptedQRCode;
    private $decryptedQRCode;
    private $restaurantID;
    private $connect;
    private $cipher;

    public function __construct($encryptedQrCode, $decryptedQrCode = null)
    {
        $this->encryptedQRCode = $encryptedQrCode;
        $this->decryptedQRCode = $decryptedQrCode;
        $cipher=new MCrypt($this->ENCRYPTION_KEY);
        if($this->encryptedQRCode !=null)
            $this->decryptedQRCode=$cipher->decrypt($this->encryptedQRCode);
        if($this->decryptedQRCode !=null)
            $this->encryptedQRCode=$cipher->encrypt($this->decryptedQRCode);
    }
    
    /**
     * @return mixed
     */
    public function getRestaurantID()
    {
        $this->connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');
        $query = "SELECT restaurant_id as id FROM QrCode WHERE decrypted_qr_code = '$this->decryptedQRCode' AND valid = '1'";
        $res = mysqli_query($this->connect, $query);
        $fResult = mysqli_fetch_assoc($res);
        $this->restaurantID = $fResult['id'];
        return $this->restaurantID;
    }

    /**
     * @return mixed
     */
    public function getDecryptedQRCode()
    {
        return $this->decryptedQRCode;
    }

    /**
     * @return mixed
     */
    public function getEncryptedQRCode()
    {
        return $this->encryptedQRCode;
    }
}

?>