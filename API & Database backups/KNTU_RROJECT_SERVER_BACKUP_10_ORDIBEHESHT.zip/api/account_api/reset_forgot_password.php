<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");
 
    if($connect)
    {
        $response=[];
        $password=$_GET['password'];
        $phone=$_GET['phone'];
        
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
                
        }
     
             
                    $query="UPDATE NormalUser SET password = '$password' WHERE phone = '$phone'";
                    $qRes=mysqli_query($connect,$query);
                    if($qRes){
                        $response['code']=101;
                        $deleteActivationCodeQuery="DELETE FROM ActivationCode WHERE pusheID = '$pusheID'";
                        mysqli_query($connect,$deleteActivationCodeQuery);
                        $fetchUsernameQuery="SELECT phone FROM NormalUser WHERE pusheID = '$pusheID'";
                        $getUserQueryRes=mysqli_query($connect,$fetchUsernameQuery);
                        while($getUsernameFetchRes=mysqli_fetch_assoc($getUserQueryRes)){
                            $phone=substr($getUsernameFetchRes['phone'],4);
                            break;
                        }
                        $response['message']=$phone;
                    }else{
                        $response['code']=102;
                        $response['message']='خطا در تعویض کلمه عبور';
                    }   
                
        die(json_encode($response));   
    }
?>