<?php
define('HOSTNAME', 'localhost');
define('USERNAME', 'cpres873_Aban');
define('PASSWORD', 'KimiaAndMohammad');
define('DATABASE', 'cpres873_KNTU_Database');

$connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");

if ($connect) {
    $headers = getallheaders();
    $response = [];

    $query = "SELECT question,answer FROM FAQ ORDER BY priority desc";
    $qRes = mysqli_query($connect, $query);
    while ($res = mysqli_fetch_assoc($qRes)) {
        $item['question'] = $res['question'];
        $item['answer'] = $res['answer'];
        array_push($response, $item);
    }
    die(json_encode($response));
}
?>