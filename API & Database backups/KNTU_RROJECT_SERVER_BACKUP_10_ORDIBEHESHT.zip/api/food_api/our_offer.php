<?php
require_once('../UserValidator.php');
require_once('../QRCodeCipher.php');
define('HOSTNAME', 'localhost');
define('USERNAME', 'cpres873_Aban');
define('PASSWORD', 'KimiaAndMohammad');
define('DATABASE', 'cpres873_KNTU_Database');

$connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");
if ($connect) {
    $token = null;
    $code = null;
    $sharedKey = null;
    $headers = getallheaders();
    foreach ($headers as $key => $val) {
        if (strcmp($key, "Token") == 0)
            $token = $val;
        if (strcmp($key, "Code") == 0)
            $code = $val;
        if (strcmp($key, "Encsharedkey") == 0)
            $sharedKey = $val;
    }

    $UserValidator = new UserValidator($token);
    if ($UserValidator->isValidUser()) {
        $QRCodeCipher = new QRCodeCipher($code);
        $restaurantID = $QRCodeCipher->getRestaurantID();
        $query = "SELECT Off.id as id,Off.percentage,RelFoodOff.food_id as food_id FROM RelFoodOff,Food,Off WHERE Food.restaurant_id='$restaurantID' AND valid='1' AND Off.id=RelFoodOff.off_id AND Food.id=RelFoodOff.food_id AND Food.deleted='0' AND Food.valid_to_cook='1'";
        $res = mysqli_query($connect, $query);
        $return_arr = [];
        while ($row = mysqli_fetch_assoc($res)) {
            $row_array['id'] = $row['id'];
            $row_array['foodID'] = $row['food_id'];
            $row_array['discountPercentage'] = $row['percentage'];
            array_push($return_arr, $row_array);
        }
        die(json_encode($return_arr));
    }
}
?>

