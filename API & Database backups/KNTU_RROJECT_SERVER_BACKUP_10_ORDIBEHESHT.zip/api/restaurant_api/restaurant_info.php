<?php
require_once('../UserValidator.php');
require_once('../QRCodeCipher.php');
require_once('../MCrypt.php');
define('HOSTNAME', 'localhost');
define('USERNAME', 'cpres873_Aban');
define('PASSWORD', 'KimiaAndMohammad');
define('DATABASE', 'cpres873_KNTU_Database');

$connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");
if ($connect) {

    $token = null;
    $sharedKey = null;
    $headers = getallheaders();
    foreach ($headers as $key => $val) {
        if (strcmp($key, "Token") == 0)
            $token = $val;
        else if (strcmp($key, "Encsharedkey") == 0)
            $sharedKey = $val;
    }

    $qrCode = $_GET['qrCode'];
    $UserValidator = new UserValidator($token);
    if ($UserValidator->isValidUser()) {
        $QRCodeCipher = new QRCodeCipher($qrCode);
        $restaurantID = $QRCodeCipher->getRestaurantID();
        $query = "SELECT Gallery.one,Restaurant.id,Restaurant.name,Address.id as address_id,Address.country,Address.state,Address.city,Address.street1,Address.street2,Address.alley1,Address.alley2,Address.block,Address.floor,Address.unit,Address.orientation,RestaurantType.name as type,Restaurant.phone,site FROM Restaurant,RestaurantType,Address,Gallery WHERE Restaurant.id = '$restaurantID' AND Restaurant.type_id =RestaurantType.id AND Restaurant.address_id = Address.id AND Restaurant.pictures_id = Gallery.id";
        $cipher = new MCrypt($sharedKey);
        $qRes = mysqli_query($connect, $query);
        $res = mysqli_fetch_assoc($qRes);
        $item['id'] = $res['id'];
        $item['type'] = $cipher->encrypt($res['type']);
        $item['name'] = $cipher->encrypt($res['name']);
        $item['phone'] = $cipher->encrypt($res['phone']);
        $item['site'] = $cipher->encrypt($res['site']);
        $item['encryptedCode'] = $cipher->encrypt($qrCode);
        $address['country'] = $cipher->encrypt($res['country']);
        $address['state'] = $cipher->encrypt($res['state']);
        $address['city'] = $cipher->encrypt($res['city']);
        $address['street1'] = $cipher->encrypt($res['street1']);
        $address['street2'] = $cipher->encrypt($res['street2']);
        $address['alley1'] = $cipher->encrypt($res['alley1']);
        $address['alley2'] = $cipher->encrypt($res['alley2']);
        $address['block'] = $cipher->encrypt($res['block']);
        $address['floor'] = $res['floor'];
        $address['unit'] = $cipher->encrypt($res['unit']);
        $address['orientation'] = $cipher->encrypt($res['orientation']);
        $item['address'] = $address;
        $pictures = [];
        array_push($pictures, $res['one']);
        $item['pictures'] = $pictures;
        die(json_encode($item));
    }
}
?>