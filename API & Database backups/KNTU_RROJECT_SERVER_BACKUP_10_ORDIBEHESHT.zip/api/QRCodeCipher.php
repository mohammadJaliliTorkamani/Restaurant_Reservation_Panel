<?php

class QRCodeCipher
{
    private $encryptedQRCode;
    private $decryptedQRCode;
    private $restaurantID;

    public function __construct($encryptedQrCode, $decryptedQrCode = null)
    {
        $this->encryptedQRCode = $encryptedQrCode;
        $this->decryptedQRCode = $decryptedQrCode;
    }

    /**
     * simple method to encrypt or decrypt a plain text string
     * initialization vector(IV) has to be the same when encrypting and decrypting
     *
     * @param string $action : can be 'encrypt' or 'decrypt'
     *
     * @return string
     */
    public function encrypt_decrypt($action)
    {
        $connect = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DATABASE) or die('Unable to Connect');
        if ($connect) {
            file_put_contents("QWEWE", $this->encryptedQRCode."%%%%%".$action."^^^".$this->decryptedQRCode);
            if (($this->$encryptedQRCode == null && $action == 'decrypt') || ($this->$decryptedQRCode == null && $action == 'encrypt')) {
                return null;
            }

            $query = "SELECT restaurant_id as id FROM QrCode WHERE decrypted_qr_code = '$this->decryptedQRCode' AND valid = '1'";
            

            $res = mysqli_query($connect, $query);
            if (mysqli_num_rows($res) == 0)
                return null;
            $fResult = mysqli_fetch_assoc($res);
            $this->restaurantID = $fResult['id'];

            $output = false;
            $encrypt_method = "AES-256-CBC";
            $secret_key = 'This is my secret key';
            $secret_iv = 'This is my secret iv';
            // hash
            $key = hash('sha256', $secret_key);

            // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
            $iv = substr(hash('sha256', $secret_iv), 0, 16);
            if ($action == 'encrypt') {
                $output = openssl_encrypt($this->encryptedQRCode, $encrypt_method, $key, 0, $iv);
                $output = base64_encode($output);
                $this->encryptedQRCode = $output;
            } else if ($action == 'decrypt') {
                $output = openssl_decrypt(base64_decode($this->encryptedQRCode), $encrypt_method, $key, 0, $iv);
                $this->decryptedQRCode = $output;
            }

            return $output;
        }
    }

    /**
     * @return mixed
     */
    public function getRestaurantID()
    {
        return $this->restaurantID;
    }

    /**
     * @return mixed
     */
    public function getDecryptedQRCode()
    {
        return $this->decryptedQRCode;
    }

    /**
     * @return mixed
     */
    public function getEncryptedQRCode()
    {
        return $this->encryptedQRCode;
    }
}

?>