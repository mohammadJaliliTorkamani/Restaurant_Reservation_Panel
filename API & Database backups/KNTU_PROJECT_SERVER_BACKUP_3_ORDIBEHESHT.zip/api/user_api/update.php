<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_user1');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_restaurant1db');

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 
    if($connect)
    {   
        $token=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
        }
        
        $user_table="Token";
        $user_verify_check_query="SELECT * FROM ".$user_table." WHERE token = '".$token."'";
         if(mysqli_num_rows(mysqli_query($connect,$user_verify_check_query))>0){
            $_table_normalUser="NormalUser";
            $data = file_get_contents('php://input');
            $newUser = json_decode($data , true);
            $query="UPDATE ".$_table_normalUser." SET name = '".$newUser['name']."',lastName='".$newUser['lastName']."',phoneNumber='".$newUser['phone']."',email='".$newUser['email']."',address='".$newUser['address']."',cash='".$newUser['cash']."' WHERE token_id = (SELECT id FROM ".$user_table." WHERE value = '$token')";
            if(mysqli_query($connect,$query))
                echo 1;
            else
                echo 2;
            die('');
        }else{
			 http_response_code(774);
             echo NULL;   
        }
    }
?>