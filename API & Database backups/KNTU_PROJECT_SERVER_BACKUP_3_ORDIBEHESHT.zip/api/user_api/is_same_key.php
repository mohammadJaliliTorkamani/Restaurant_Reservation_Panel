<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_user1');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_restaurant1db');

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 
    if($connect)
    {   
        $sharedKey=$_GET['shared_key'];
        $token=null;
        $code=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
        }
        $query="SELECT shared_key FROM Token WHERE value = '$token' AND shared_key = '$sharedKey'";
        $res=mysqli_query($connect,$query);
        if(mysqli_num_rows($res)>0){
            while($row=mysqli_fetch_array($res))
            {
                echo (strcmp($sharedKey,$row['shared_key'])==0);   
            }
        }else{
			http_response_code(774);
            echo 0;
        }
    }
?>