<?php
require_once('../MCrypt.php');
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 
    if($connect)
    {   
		$token=null;
        $code=null;
        $sharedKey=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
            if(strcmp($key,"Sharedkey")==0)
                $sharedKey=$val;
                
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);

        $tokenCheckQuery="SELECT * FROM RelNormalUserPusheID,NormalUser WHERE pusheID = '$pusheID' AND NormalUser.id = RelNormalUserPusheID.normal_user_id";
        $fRes=mysqli_query($connect,$tokenCheckQuery);
        $cypher=new MCrypt($sharedKey);
        if(mysqli_num_rows($fRes)>0){
            $sSQL= 'SET CHARACTER SET utf8'; 
            mysqli_query($connect,$sSQL) ;
            if($token!=null){
                $query="SELECT * FROM NormalUser,QrCode,Token WHERE QrCode.decrypted_qr_code = '$decryptedCode' AND NormalUser.id = Token.user_id AND Token.value='$token'";
                while($res=mysqli_fetch_assoc(mysqli_query($connect,$query))){
                    try{
                        $toReturn['name']=$cypher->encrypt($res['name']);
                        $toReturn['lastName']=$cypher->encrypt($res['last_name']);
                        $toReturn['cash']=$res['cash'];
                        $toReturn['phone']=$cypher->encrypt($res['phone']);
                    }catch(Excecption $e){
                        file_put_contents("Encryption Error File",json_encode($e));
                    }
                    die(json_encode($toReturn));
                }
            }else{
                try{
                    $toReturn['name']=$cypher->encrypt("میهمان ");
                    $toReturn['lastName']=$cypher->encrypt("جدید!");
                    $toReturn['phone']=$cypher->encrypt("-1");
                    die(json_encode($toReturn));
                }catch(Excecption $e){
                    file_put_contents("Encryption Error File",json_encode($e));
                }
            }
        }else{
    		http_response_code(774);
            die(NULL);   
        }
    }
?>