<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 mysqli_set_charset($connect, "utf8");
    if($connect)
    {   
        $token=null;
        $code=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);

        $user_verify_check_query="SELECT user_id FROM Token WHERE value = '$token' AND user_role = 'normal'";
        $tokenRes=mysqli_query($connect,$user_verify_check_query);
        if(mysqli_num_rows($tokenRes)>0){
            $user_verify_check_query="SELECT * FROM Token,QrCode WHERE Token.value = '$token' AND QrCode.decrypted_qr_code = '$decryptedCode'";
            if(mysqli_num_rows(mysqli_query($connect,$user_verify_check_query))>0){
                $code=$_GET["code"];
                $query="SELECT * FROM Discount WHERE is_valid='1' AND used_times< max_usage AND code = '$code'";
                $res=mysqli_query($connect,$query);
                if(mysqli_num_rows($res)>0){
                    while($fetchRes=mysqli_fetch_assoc($res)){
                        $discount['id']=$fetchRes['id'];
                        $discount['code']=$fetchRes['code'];
                        $discount['percentage']=$fetchRes['percentage'];
                        $discount['minimumAcceptablePrice']=$fetchRes['minimum_acceptable_price'];
                    }
                
                    $discountID=$discount['id'];
                    $query="SELECT * FROM  RelNormalUserDiscount,Token WHERE RelNormalUserDiscount.discount_id='$discountID' AND RelNormalUserDiscount.normal_user_id = Token.user_id AND Token.user_role='normal' AND Token.value = '$token'";
                    $queryRes=mysqli_query($connect,$query);
                    if(mysqli_num_rows($queryRes)>0){
                        $discount['id']=-1;
                        die(json_encode($discount));
                    }else{
                        die(json_encode($discount));
                    }
                }else{
                    $discount['id']=-2;
                    die(json_encode($discount));       
                }
            }
        }else{
			http_response_code(774);
            die(NULL);
        }
    }
?>