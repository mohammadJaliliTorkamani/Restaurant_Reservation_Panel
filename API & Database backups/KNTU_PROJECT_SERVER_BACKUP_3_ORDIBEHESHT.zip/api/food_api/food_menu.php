<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 mysqli_set_charset($connect, "utf8");
    if($connect)
    {   
        
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);

        $user_verify_check_query="SELECT * FROM RelNormalUserPusheID WHERE pusheID = '$pusheID'";
        if(mysqli_num_rows(mysqli_query($connect,$user_verify_check_query))>0){
            $tableName_food="Food";
            $tableName_category="Category";
            $tableName_rel_food_category="RelFoodCategory";
            
            $query="SELECT Gallery.one as one,Gallery.two as two,Gallery.three as three ,Gallery.four as four,Category.id as id, Category.name as name,Category.color as color FROM Category,RelCategoryRestaurant,Gallery,QrCode WHERE Gallery.id = Category.logos_id AND RelCategoryRestaurant.restaurant_id = QrCode.restaurant_id AND QrCode.decrypted_qr_code = '$decryptedCode' AND Category.id = RelCategoryRestaurant.category_id AND RelCategoryRestaurant.is_valid='1'";

            $res=mysqli_query($connect,$query);
            $final_return_arr=array();
            while($category=mysqli_fetch_assoc($res))
            {
                $temp_array=array();
                $food_array=array();    
                $query2="SELECT Food.id as id,Food.name as name,Food.calories as calorie,Food.cook_time_minutes as cookTime,Food.description as description,Food.price as price,Food.like_number as likeNumber,Gallery.one as one,Gallery.two as two,Gallery.three as three , Gallery.four as four FROM Food,RelFoodCategory,QrCode,Gallery,RelCategoryRestaurant WHERE RelFoodCategory.food_id = Food.id AND  RelFoodCategory.category_id = ".$category['id']." AND QrCode.decrypted_qr_code = '$decryptedCode' AND Gallery.id = Food.pictures_id AND QrCode.restaurant_id = Food.restaurant_id AND RelCategoryRestaurant.is_valid='1' AND RelCategoryRestaurant.category_id = ".$category['id']." AND RelCategoryRestaurant.restaurant_id = QrCode.restaurant_id AND Food.deleted='0' AND Food.valid_to_cook='1'";
				//prepare food list
                $res2=mysqli_query($connect,$query2);
                while($row=mysqli_fetch_assoc($res2))
                {
                    $row_array['id']=$row['id'];
                    $row_array['name']=$row['name'];
                    $row_array['calories']=$row['calorie'];
                    $row_array['cookTimeMinutes']=$row['cookTime'];
                    $row_array['description']=$row ['description'];
                    $row_array['price']=$row['price'];
                    $row_array['likeNumber']=$row['likeNumber'];
                    $photos=[];
                    array_push($photos,$row['one']);
                    array_push($photos,$row['two']);
                    array_push($photos,$row['three']);
                    array_push($photos,$row['four']);
                    $row_array['pictures']=$photos;
                    array_push($food_array,$row_array);
                }
                
                //prepare category
                $final_category['id']=$category['id'];
                $final_category['name']=$category['name'];
                $final_category['color']=$category['color'];
                $photos=[];
                array_push($photos,$category['one']);
                array_push($photos,$category['two']);
                array_push($photos,$category['three']);
                array_push($photos,$category['four']);
                $final_category['logos']=$photos;
                //
                $return_arr['category']=$final_category;
                $return_arr['foodList']=$food_array;
                array_push($final_return_arr,$return_arr);

            }
            echo json_encode($final_return_arr);
        }else
            return NULL;
    }
?>

