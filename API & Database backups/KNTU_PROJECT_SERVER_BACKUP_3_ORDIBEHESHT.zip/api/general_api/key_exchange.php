<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 
    if($connect)
    {   
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
                
        }
         $user_verify_check_query="SELECT * FROM RelNormalUserPusheID WHERE pusheID = '$pusheID'";
        if(mysqli_num_rows(mysqli_query($connect,$user_verify_check_query))>0){
            $G=6;
    	    $Prime=13;
            $server_private_key=rand(2,15); 
            $y=pow($G,$server_private_key)%$Prime;
            $x=$_GET["client_private_key"]; 
        
            $shared_key=pow($x,$server_private_key)%$Prime;
			
            $query="UPDATE Token SET shared_key = '$shared_key' WHERE value = '$token'";
            $res=mysqli_query($connect,$query);
            echo $y;   
        }else{
            echo -1;
        }
    }

?>