<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}



$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");
 
    if($connect)
    {
        $tokenValue=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $tokenValue=$val;
            else if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
            else if(strcmp($key,"Versioncode")==0)
                $versionCode=$val;
        }
        $query="SELECT MAX(version_code) AS max FROM LogCat";
        $qRes=mysqli_query($connect,$query);
        $maxVersion=-1;
        if($qRes){
            while($res=mysqli_fetch_assoc($qRes)){
                $maxVersion=$res['max'];
            }
            if($maxVersion!=-1){
                if($maxVersion>$versionCode){
                    $query="SELECT feature FROM LogCat WHERE version_code = '$maxVersion'";
                    $res=mysqli_query($connect,$query);
                    $list=[];
                    while($fetchRes=mysqli_fetch_assoc($res)){
                        $var['versionCode']=$maxVersion;
                        $var['text']=$fetchRes['feature'];
                        array_push($list,$var);
                    }
                    $response['message']=json_encode($list);
                    $response['code']=102;
                    die(json_encode($response));
                }else{
                    $response['code']=101;
                    $colorQuery="SELECT main_color FROM App";
                    $colorRes=mysqli_query($connect,$colorQuery);
                    $color=mysqli_fetch_assoc($colorRes)['main_color'];
                    $response['message']=$color;
                    die(json_encode($response));
                }
            }
                    
        }else{
            $response=null;
        }
        die();
    }
?>