<?php
require_once('../MCrypt.php');

define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
    if($connect)
    {   
        $token=null;
        $code=null;
        $sharedKey=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Sharedkey")==0)
                $sharedKey=$val;
                
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);
        $cypher=new MCrypt($sharedKey);
        $user_verify_check_query="SELECT * FROM Token,QrCode WHERE value = '$token' AND QrCode.decrypted_qr_code = '$decryptedCode'";
        if(mysqli_num_rows(mysqli_query($connect,$user_verify_check_query))>0){
            $return_obj['marchantID']=$cypher->encrypt("645f93e8-8cd4-11e9-9345-000c29344814");
            $return_obj['email']=$cypher->encrypt("financial@aban.dev");    
            $return_obj['phone']=$cypher->encrypt("+989016273209");
        }
        die(json_encode($return_obj));
    }
?>