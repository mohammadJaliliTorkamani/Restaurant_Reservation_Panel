<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}



$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
    if($connect)
    {
		$token=null;
        $code=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
                
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);
        $user_verify_check_query="SELECT * FROM Token,QrCode WHERE value = '$token' AND QrCode.decrypted_qr_code = '$decryptedCode'";
		$query=mysqli_query($connect,$user_verify_check_query);
		if(mysqli_num_rows($query)==0){
			http_response_code(774);
			die(NULL);
		}else{
			$data = json_decode(file_get_contents('php://input'),true);
			$number=$data['n'];
			$totalSum=0;
			$totalChairNumber=0;
			$bills=$data['bills'];
			
			foreach($bills as $bill){
				$foodID=$bill["foodID"];
				if($foodID!=-1){
	     			$query="SELECT Food.price FROM Food WHERE Food.id = '$foodID'";
					$result=mysqli_query($connect,$query);
					$price=mysqli_fetch_assoc($result)["price"];
					$totalSum=$totalSum+$price*$bill["counter"];
				}else{
					$totalChairNumber=$totalChairNumber+1;
				}
			}
			
			$minFoodQuery="SELECT MIN(price) as minimum FROM Food,QrCode WHERE Food.restaurant_id = QrCode.restaurant_id AND QrCode.decrypted_qr_code = '$decryptedCode' AND deleted = '0' AND valid_to_cook = '1'";
			$minFoodRes=mysqli_query($connect,$minFoodQuery);
			while($minFoodFetchRes=mysqli_fetch_assoc($minFoodRes)){
				$mimimumPrice=$minFoodFetchRes['minimum'];
				$ans=($totalChairNumber<=1.5*$number)   &&    ($number*0.75*$mimimumPrice<=$totalSum);
				$response['code']=102;
				if($ans)
					$response['code']=101;	
				die(json_encode($response));
			}
        }
        die();
    }
?>