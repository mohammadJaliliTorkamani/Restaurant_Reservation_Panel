<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}



$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");
 
    if($connect)
    {

        $tokenValue=null;
        $qrCode=null;
        $pusheID=null;
        $order=$_GET['order'];
        
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $tokenValue=$val;
            if(strcmp($key,"Code")==0)
                $qrCode=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
        }
        
        $response=[];
        $decryptedQr = encrypt_decrypt('decrypt', $qrCode);
        $query="SELECT FAQ.question as question,FAQ.answer as answer,FAQ.priority as priority,FAQ.shown as shown,Gallery.one as one FROM FAQ,Gallery,QrCode,RelNormalUserPusheID WHERE RelNormalUserPusheID.pusheID = '$pusheID' AND Gallery.id = FAQ.image_id AND QrCode.decrypted_qr_code = '$decryptedQr' ORDER BY '$order'";
        $qRes=mysqli_query($connect,$query);
        if($qRes){
            if(mysqli_num_rows($qRes)>0){
                while($res=mysqli_fetch_assoc($qRes)){
                    $item['question']=$res['question'];
                    $item['answer']=$res['answer'];
                    $item['image']=$res['one'];
                    $item['shown']=$res['shown'] ;
                    $item['priority']=$res['priority'];
                    array_push($response,$item);
                }
            }else{
                $response=null;
            }
        }else{
            $response=null;
        }
        echo json_encode($response); 
        die();
    }
?>