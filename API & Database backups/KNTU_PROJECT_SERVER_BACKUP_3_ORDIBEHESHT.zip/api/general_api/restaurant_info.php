<?php
require_once('../MCrypt.php');

define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}



$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
mysqli_set_charset($connect, "utf8");
 
    if($connect)
    {
        
        $tokenValue=null;
        $pusheID=null;
        $headers = getallheaders();
        $sharedKey=null;
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $tokenValue=$val;
            else if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
            if(strcmp($key,"Sharedkey")==0)
                $sharedKey=$val;
                if(strcmp($key,"Sharedkey")==0)
                $sharedKey=$val;
        }
        
        $response=[];
        $qrCode=$_GET['qrCode'];
        $decryptedQr = encrypt_decrypt('decrypt', $qrCode);
        
        $query="SELECT Gallery.one,Gallery.two,Gallery.three,Gallery.four,Restaurant.id,Restaurant.name as name,Address.id as address_id,Address.country as country,Address.state as state,Address.city as city,Address.street1 as street1,Address.street2 as street2,Address.alley1 as alley1,Address.alley2 as alley2,Address.block as block,Address.floor as floor,Address.unit as unit,Address.orientation orientation,Address.x as x,Address.y as y,RestaurantType.name as type,owner_id,Restaurant.phone as phone ,site FROM Restaurant,QrCode,RestaurantType,Address,Gallery,RelNormalUserPusheID WHERE QrCode.restaurant_id = Restaurant.id AND decrypted_qr_code = '$decryptedQr' AND Restaurant.type_id =RestaurantType.id AND Restaurant.address_id = Address.id AND Restaurant.pictures_id = Gallery.id AND RelNormalUserPusheID.pusheID='$pusheID'";

        $qRes=mysqli_query($connect,$query);
        if($qRes){
            $cypher=new MCrypt($sharedKey);
            if(mysqli_num_rows($qRes)>0){
                while($res=mysqli_fetch_assoc($qRes)){
                    $item['id']=$res['id'];
                    $item['type']=$cypher->encrypt($res['type']);
                    $item['name']=$cypher->encrypt($res['name']);
                    $item['phone']=$cypher->encrypt($res['phone']);
                    $item['ownerID']=$res['owner_id'];
                    $item['site']=$cypher->encrypt($res['site']);
                    $item['encryptedCode']=$cypher->encrypt($qrCode);
                    $address['country']=$cypher->encrypt($res['country']);
                    $address['state']=$cypher->encrypt($res['state']);
                    $address['city']=$cypher->encrypt($res['city']);
                    $address['street1']=$cypher->encrypt($res['street1']);
                    $address['street2']=$cypher->encrypt($res['street2']);
                    $address['alley1']=$cypher->encrypt($res['alley1']);
                    $address['alley2']=$cypher->encrypt($res['alley2']);
                    $address['block']=$cypher->encrypt($res['block']);
                    $address['floor']=$res['floor'];
                    $address['unit']=$cypher->encrypt($res['unit']);
                    $address['orientation']=$cypher->encrypt($res['orientation']);
                    $address['x']=$res['x'];
                    $address['y']=$res['y'];
                    $item['address']=$address;
                    $pictures=[];
                    array_push($pictures,$res['one']);
                    array_push($pictures,$res['two']);
                    array_push($pictures,$res['three']);
                    array_push($pictures,$res['four']);
                    $item['pictures']=$pictures;
                    array_push($response,$item);
                }
            }else{
                $response=null;
            }
        }else{
            $response=null;
        }
        echo json_encode($response[0]); 
        die();
    }
?>