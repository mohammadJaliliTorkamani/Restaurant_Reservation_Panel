<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 mysqli_set_charset($connect, "utf8");
    if($connect)
    {   
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);

        $user_verify_check_query="SELECT columns_of_table FROM RelNormalUserPusheID,QrCode,Restaurant WHERE pusheID = '$pusheID' AND QrCode.decrypted_qr_code = '$decryptedCode' AND QrCode.restaurant_id = Restaurant.id";
        while($res=mysqli_fetch_assoc(mysqli_query($connect,$user_verify_check_query))){
            echo $res['columns_of_table'];
            die('');
        }
    }
?>