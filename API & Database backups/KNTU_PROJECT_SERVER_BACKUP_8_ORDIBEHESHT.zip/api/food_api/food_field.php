<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 mysqli_set_charset($connect, "utf8");
    if($connect)
    {   
        
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);

        $return_arr=[];
       
            $_table_weLove="PopularFood";
            $_table_foodMeal="RelFoodMeal";
            $_table_meal="Meal";
            $food_id=$_GET['food_id'];
            $q1="SELECT * FROM PopularFood,Food,QrCode WHERE Food.id = ".$food_id . " AND Food.id = PopularFood.food_id AND Food.restaurant_id = QrCode.restaurant_id AND Food.deleted='0' AND Food.valid_to_cook='1'";
            $q2="SELECT * FROM RelFoodMeal,Meal,Food,QrCode WHERE ".$_table_foodMeal.".meal_id = ".$_table_meal.".id"." AND Food.id = ".$food_id. " AND Food.id = RelFoodMeal.food_id AND Food.restaurant_id = QrCode.restaurant_id AND Food.deleted='0' AND Food.valid_to_cook='1'";
            $q3="SELECT Off.percentage FROM Off,RelFoodOff,Food,QrCode WHERE Food.id = ".$food_id. " AND Food.id = RelFoodOff.food_id AND Food.restaurant_id = QrCode.restaurant_id AND Off.id = RelFoodOff.off_id AND Food.id = RelFoodOff.food_id AND Food.deleted='0' AND Food.valid_to_cook='1'";
            $rr=mysqli_query($connect,$q1);
            if($rr){
                if(mysqli_num_rows($rr)>0)
                {
                    array_push($return_arr,"popular");
                    array_push($return_arr,"null");
                    echo json_encode($return_arr);
                    die('');
                }else{
                    $rr=mysqli_query($connect,$q2);
                    if($rr){
                        if(mysqli_num_rows($rr)>0){
                            while($meal=mysqli_fetch_assoc($rr)){
                                array_push($return_arr,"today");
                                array_push($return_arr,$meal['name']);
                                echo json_encode($return_arr);
                                die('');
                            }
                        }else{
                            $rr=mysqli_query($connect,$q3);
                            if($rr){
                                if(mysqli_num_rows($rr)>0){
                                    while($offer=mysqli_fetch_assoc($rr)){
                                        array_push($return_arr,"offer");
                                        array_push($return_arr,$offer['percentage']);
                                        echo json_encode($return_arr);
                                        die('');
                                    }
                                }else{
                                    array_push($return_arr,"null");
                                    array_push($return_arr,"null");
                                    echo json_encode($return_arr);
                                    die('');
                                }
                            }
                        }
                    }
                }
            }
       
    }
?>

