<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 mysqli_set_charset($connect, "utf8");
    if($connect)
    {   
        
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);

        $token_table="Token";
        $foodID=$_GET['food_id'];
        
             $query="SELECT Food.id as id,Food.name as name,Food.calories as calorie,Food.cook_time_minutes as cookTime,Food.description as description,Food.price as price,Food.like_number as likeNumber,Gallery.one as one,Gallery.two as two,Gallery.three as three,Gallery.four as four,QrCode.decrypted_qr_code as decrypted_qr_code FROM Food,Gallery,QrCode WHERE Food.id = '$foodID' AND Food.pictures_id = Gallery.id AND 
                Food.restaurant_id = QrCode.restaurant_id AND 
				Food.deleted='0' AND Food.valid_to_cook='1' AND 
                QrCode.decrypted_qr_code = '$decryptedCode'";
            $res=mysqli_query($connect,$query);
            $return_arr=array();
            while($row=mysqli_fetch_assoc($res))
            {
                $row_array['id']=$row['id'];
                $row_array['name']=$row['name'];
                $row_array['calories']=$row['calorie'];
                $row_array['cookTimeMinutes']=$row['cookTime'];
                $row_array['description']=$row ['description'];
                $row_array['price']=$row['price'];
                $row_array['likeNumber']=$row['likeNumber'];
                $photos=[];
                array_push($photos,$row['one']);
                array_push($photos,$row['two']);
                array_push($photos,$row['three']);
                array_push($photos,$row['four']);
                $row_array['pictures']=$photos;
                array_push($return_arr,$row_array);
            }
            echo json_encode($return_arr[0]);   
       
    }
?>

