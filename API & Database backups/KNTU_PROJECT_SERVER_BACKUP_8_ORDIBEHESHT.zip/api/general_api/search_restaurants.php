<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 mysqli_set_charset($connect, "utf8");
    if($connect)
    {   
        
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
                
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);

        $restaurantName=$_GET['restaurant_name'];
            $query="SELECT QrCode.decrypted_qr_code,Restaurant.active,Gallery.one,Gallery.two,Gallery.three,Gallery.four,Restaurant.id,Restaurant.name as name,Address.id as address_id,Address.country as country,Address.state as state,Address.city as city,Address.street1 as street1,Address.street2 as street2,Address.alley1 as alley1,Address.alley2 as alley2,Address.block as block,Address.floor as floor,Address.unit as unit,Address.orientation orientation,Address.x as x,Address.y as y,RestaurantType.name as type FROM QrCode,Restaurant,RestaurantType,Address,Gallery WHERE Restaurant.type_id =RestaurantType.id AND Restaurant.address_id = Address.id AND Restaurant.pictures_id = Gallery.id AND Restaurant.id = QrCode.restaurant_id AND Restaurant.name like '%$restaurantName%' order by Restaurant.id";
            $response=[];
            $result=mysqli_query($connect,$query);
            while($res=mysqli_fetch_assoc($result))
            {
                    $item['id']=$res['id'];
                    $item['type']=$res['type'];
                    $item['name']=$res['name'];
                    $item['active']=$res['active']==1 ? true : false;
                    $item['encryptedCode']=encrypt_decrypt('encrypt',$res['decrypted_qr_code']);
                    $address['country']=$res['country'];
                    $address['state']=$res['state'];
                    $address['city']=$res['city'];
                    $address['street1']=$res['street1'];
                    $address['street2']=$res['street2'];
                    $address['alley1']=$res['alley1'];
                    $address['alley2']=$res['alley2'];
                    $address['block']=$res['block'];
                    $address['floor']=$res['floor'];
                    $address['unit']=$res['unit'];
                    $address['orientation']=$res['orientation'];
                    $address['x']=$res['x'];
                    $address['y']=$res['y'];
                    $item['address']=$address;
                    $pictures=[];
                    array_push($pictures,$res['one']);
                    array_push($pictures,$res['two']);
                    array_push($pictures,$res['three']);
                    array_push($pictures,$res['four']);
                    $item['pictures']=$pictures;
                    array_push($response,$item);
            }
            echo json_encode($response);   
     
    }
?>

