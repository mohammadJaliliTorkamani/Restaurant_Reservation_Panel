<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 
    if($connect)
    {   
        
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
                
        }
            $response=[];
            $code=$_GET['code'];
            $query="SELECT activationCode as code FROM ActivationCode WHERE pusheID = '$pusheID' ORDER BY id desc";
			if($res=mysqli_query($connect,$query)){
                if(mysqli_num_rows($res)>0){
                    while($fResult=mysqli_fetch_assoc($res)){
                        if($fResult['code']==$code){
                            $response['code']=101;        
                        }else{
                            $response['code']=102;
                            $response['message']='کد وارد شده اشتباه می باشد';
                        }
                        break;
                    }
                }else{
                    $response['code']=102;
                    $response['message']='کد فعالسازی وجود ندارد';
                }
            }else{
                $response['code']=102;
                $response['message']='خطای ناشناخته !';
            }
            echo json_encode($response); 
            die();   
    }
?>