<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");

function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 mysqli_set_charset($connect, "utf8");
    if($connect)
    {   
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
                
                
        }
        $decryptedCode=encrypt_decrypt('decrypt',$code);

        $deskID=$_GET['desk_id'];
             $query="SELECT Desk.top_chair_id as top_chair_id,
             Desk.start_chair_id as start_chair_id,Desk.end_chair_id as end_chair_id,
             Desk.bottom_chair_id as bottom_chair_id FROM Desk,QrCode,LexinTable,RelDeskLexinTable
             WHERE LexinTable.restaurant_id = QrCode.restaurant_id AND Desk.id = '$deskID' AND RelDeskLexinTable.lexin_table_id = LexinTable.id AND RelDeskLexinTable.desk_id = Desk.id
             AND QrCode.decrypted_qr_code = '$decryptedCode' AND LexinTable.is_valid='1'";

            $res=mysqli_query($connect,$query);
            $return_arr=array();
            while($row=mysqli_fetch_assoc($res))
            {
                $dateObj=strtotime($date);
                
                $startChair['id']=$row['start_chair_id'];
                $endChair['id']=$row['end_chair_id'];
                $topChair['id']=$row['top_chair_id'];   
                $bottomChair['id']=$row['bottom_chair_id'];
				$startChair['deskID']=$deskID;
                $endChair['deskID']=$deskID;
                $topChair['deskID']=$deskID;   
                $bottomChair['deskID']=$deskID;
                
                $row_array['topChair']=$topChair;
                $row_array['bottomChair']=$bottomChair;
                $row_array['startChair']=$startChair;
                $row_array['endChair']=$endChair;
                echo json_encode($row_array);
            }
       
    }
?>

