<?php
define('HOSTNAME','localhost');
define('USERNAME','cpres873_Aban');
define('PASSWORD','KimiaAndMohammad');
define('DATABASE','cpres873_KNTU_Database');
define("ENCRYPTION_KEY", "!@#$%^&*");
class gregorian2jalali
{
      // $mydate format must follow this format: 2007-02-12-1  (yyyy-mm-dd-D)
      // If $mydate is not set, current date will be returned.
      var $mydate = "";

      function Get_Date() {
          if ($year == "")
            $year = date('Y');
          if ($month == "")
            $month = date('m');
          if ($day == "")
            $day = date('d');
          if ($d == "")
            $d = date('w');

          return $year."-".$month."-".$day."-".$d;
      }


	  function div($a,$b) {
	  	return (int) ($a / $b);
	  }


	  function gregorian_to_jalali ($format="yyyy/mm/dd")
	  {

          $week= Array("&#1610;&#1603;&#1588;&#1606;&#1576;&#1607;","&#1583;&#1608;&#1588;&#1606;&#1576;&#1607;","&#1587;&#1607; &#1588;&#1606;&#1576;&#1607;","&#1670;&#1607;&#1575;&#1585;&#1588;&#1606;&#1576;&#1607;","&#1662;&#1606;&#1580;&#8204;&#1588;&#1606;&#1576;&#1607;","&#1580;&#1605;&#1593;&#1607;","&#1588;&#1606;&#1576;&#1607;");
          $months = Array("&#1601;&#1585;&#1608;&#1585;&#1583;&#1610;&#1606;","&#1575;&#1585;&#1583;&#1610;&#1576;&#1607;&#1588;&#1578;","&#1582;&#1585;&#1583;&#1575;&#1583;","&#1578;&#1610;&#1585;","&#1605;&#1585;&#1583;&#1575;&#1583;","&#1588;&#1607;&#1585;&#1610;&#1608;&#1585;","&#1605;&#1607;&#1585;","&#1570;&#1576;&#1575;&#1606;","&#1570;&#1584;&#1585;","&#1583;&#1610;","&#1576;&#1607;&#1605;&#1606;","&#1575;&#1587;&#1601;&#1606;&#1583;");

        if (($this->mydate)=="")
            $this->mydate = $this->Get_Date();

		$g_y = mb_substr($this->mydate, 0, 4);
		$g_m = mb_substr($this->mydate, 5, 2);
		$g_d = mb_substr($this->mydate, 8, 2);
		$d = mb_substr($this->mydate, 11, 1);


		$g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		$j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);
		$gy = $g_y-1600;
		$gm = $g_m-1;
		$gd = $g_d-1;
		$g_day_no = 365*$gy+$this->div($gy+3,4)-$this->div($gy+99,100)+$this->div($gy+399,400);
		for ($i=0; $i < $gm; ++$i)
		$g_day_no += $g_days_in_month[$i];
		if ($gm>1 && (($gy%4==0 && $gy%100!=0) || ($gy%400==0)))
		/* leap and after Feb */
		$g_day_no++;
		$g_day_no += $gd;
		$j_day_no = $g_day_no-79;
		$j_np = $this->div($j_day_no, 12053); /* 12053 = 365*33 + 32/4 */
		$j_day_no = $j_day_no % 12053;
		$jy = 979+33*$j_np+4*$this->div($j_day_no,1461); /* 1461 = 365*4 + 4/4 */
		$j_day_no %= 1461;
		if ($j_day_no >= 366) {
		$jy += $this->div($j_day_no-1, 365);
		$j_day_no = ($j_day_no-1)%365;
		
		}
		for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i)
		$j_day_no -= $j_days_in_month[$i];
		$jm = $i+1;
		$jd = $j_day_no+1;
		$jy_s = mb_substr($jy, 2, 2);
		if ($jd<10)
			$jd = "0".$jd;
		
		switch ($format) {
		case "yy M dd D":
			return  ($week[$d]." ".$jd." ".$months[$jm-1]." ".$jy);
			break;
		case "yy/mm/dd":
			if ($jm<10)
				$jm = "0".$jm;
			return  ($jy_s."/".$jm."/".$jd);
			break;
		case "yyyy/mm/dd":
			if ($jm<10)
				$jm = "0".$jm;
			return  ($jy."/".$jm."/".$jd);
			break;
		case "dd":
			return  ($jd);
			break;
		case "mm":
			if ($jm<10)
				$jm = "0".$jm;
			return  ($jm);
			break;
		case "Y":
			return  ($jy);
			break;
		case "yyyy":
			return  ($jy);
			break;
		case "yy":
			return  ($jy_s);
			break;
		default:
		}
		
	}

}
/**
 * simple method to encrypt or decrypt a plain text string
 * initialization vector(IV) has to be the same when encrypting and decrypting
 * 
 * @param string $action: can be 'encrypt' or 'decrypt'
 * @param string $string: string to encrypt or decrypt
 *
 * @return string
 */
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';
    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);
    if ( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } else if( $action == 'decrypt' ) {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }
    return $output;
}

$connect = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DATABASE) or die('Unable to Connect');
 mysqli_set_charset($connect, "utf8");
    if($connect)
    {  
	    date_default_timezone_set("Asia/Tehran"); 
        $token=null;
        $code=null;
        $pusheID=null;
        $headers =  getallheaders();
        foreach($headers as $key=>$val){
            if(strcmp($key,"Token")==0)
                $token=$val;
            if(strcmp($key,"Code")==0)
                $code=$val;
            if(strcmp($key,"Pusheid")==0)
                $pusheID=$val;
        }
		$decryptedCode=encrypt_decrypt('decrypt',$code);
		$date=$_GET['selected_date'];
		$roof=$_GET['roof'];
		
		$dateObj=strtotime($date);
	
             $query="SELECT Desk.id as id,Desk.top_chair_id as top_chair_id,Desk.start_chair_id as start_chair_id,Desk.end_chair_id as end_chair_id,Desk.bottom_chair_id as bottom_chair_id,Desk.row_index as row_index,Desk.column_index as column_index,LexinTable.price as price,LexinTable.roof as roof,LexinTable.label as label,Desk.previous_desk_id as previous,Desk.next_desk_id as next,RelDeskLexinTable.lexin_table_id FROM Desk,QrCode,LexinTable,RelDeskLexinTable WHERE LexinTable.roof = '$roof' AND RelDeskLexinTable.lexin_table_id = LexinTable.id AND RelDeskLexinTable.desk_id = Desk.id AND LexinTable.restaurant_id = QrCode.restaurant_id AND QrCode.decrypted_qr_code = '$decryptedCode' AND LexinTable.is_valid='1'";
			$res=mysqli_query($connect,$query);
            $return_arr=array();
            while($row=mysqli_fetch_assoc($res))
            {
                $row_array['id']=$row['id'];
                $row_array['topChairID']=$row['top_chair_id'];
                $row_array['bottomChairID']=$row['bottom_chair_id'];
                $row_array['startChairID']=$row['start_chair_id'];
                $row_array['endChairID']=$row ['end_chair_id'];
                $row_array['row_index']=$row['row_index'];
                $row_array['column_index']=$row['column_index'];
                $row_array['previousDeskID']=$row['previous'];
                $row_array['nextDeskID']=$row['next'];
                $row_array['lexinTableID']=$row['lexin_table_id'];
                $row_array['price']=$row['price'];
                $row_array['roof']=$row['roof'];
                $row_array['label']=$row['label'];
				$row_array['reserved']=false; //put not reserved as default
                $checkreservedDeskQuery="SELECT start_time,end_time FROM RelDeskLexinTable,LexinTable,LexinTableOrder WHERE LexinTableOrder.lexin_table_id = LexinTable.id AND RelDeskLexinTable.lexin_table_id = LexinTable.id AND RelDeskLexinTable.desk_id = ".$row['id']." AND completed = '0' AND LexinTable.is_valid='1'";
                
                
                
				$checkreservedDeskRes=mysqli_query($connect,$checkreservedDeskQuery);
                while($checkreservedDeskFetchRes=mysqli_fetch_assoc($checkreservedDeskRes)){
                    $deskStartTime=$checkreservedDeskFetchRes['start_time'];
                    $deskEndTime=$checkreservedDeskFetchRes['end_time'];
                    $deskStartTimeObj=strtotime($deskStartTime);
                    $deskEndTimeObj=strtotime($deskEndTime);
                    if($dateObj<=$deskEndTimeObj && $dateObj>=$deskStartTimeObj)
                        $row_array['reserved']=true;
                }
                array_push($return_arr,$row_array);
            }
			die(json_encode($return_arr));   
       
    }
?>

